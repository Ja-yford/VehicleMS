const readline = require('readline');
const mysql = require('mysql');

/*
MySQL Connection 
*/

// MySQL database connection configuration
const dbConfig = {
  host: 'localhost',
  user: 'root',
  password: '123asdfghjkl',
  database: 'db_arbysms',
};

// Create MySQL connection
const connection = mysql.createConnection(dbConfig);

// Create readline interface
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Connect to MySQL and start all management systems
connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL database');  
    // Start the renter management system
    displayAllMenu();
});

/*
FUNCTIONS TO DISPLAY MENUS 
*/

// Function to display the menu for all options
function displayAllMenu() {
  console.log('\nMain Menu\n');
  console.log('1. Renter Management');
  console.log('2. Appointment Management');
  console.log('3. Truck Management');
  console.log('4. Employee Management');
  console.log('5. Rent Management');
  console.log('6. Payment Management');
  console.log('7. Exit\n');

  
  rl.question('Enter your choice: ', (choice) => {
      switch (choice) {
      case '1':
          displayRenterMenu();
        break;
      case '2':
          displayAppointmentMenu();
        break;
      case '3':
          displayTruckMenu();
        break;
      case '4':
          displayEmployeeMenu();
        break;
      case '5':
          displayRentMenu();
        break;
      case '7':
          connection.end(); // Close MySQL connection before exiting
          rl.close();
        break;
      default:
          console.log('\nInvalid choice. Please try again.\n');
        displayAllMenu();
      }
  });
}

// Function to display the renter menu
function displayRenterMenu() {
  console.log('\nRenter Management System\n');
  console.log('1. Add Renter');
  console.log('2. View All Renters');
  console.log('3. Update Renter Information');
  console.log('4. Delete Renter');
  console.log('5. Back to Main Menu\n');

  handleRenterMenuChoice();
}

// Function to display the appointment menu
function displayAppointmentMenu() {
  console.log('\nAppointment Management System\n');
  console.log('1. Add Appointment');
  console.log('2. View All Appointments');
  console.log('3. Update Appointments Information');
  console.log('4. Delete Appointment');
  console.log('5. Back to Main Menu\n');

  handleAppointmentMenuChoice();
}

// Function to display the appointment menu
function displayTruckMenu() {
  console.log('\nTruck Management System\n');
  console.log('1. Add Truck');
  console.log('2. View All Trucks');
  console.log('3. Update Trucks Information');
  console.log('4. Delete Truck');
  console.log('5. Back to Main Menu\n');

  handleTruckMenuChoice();
}

// Function to display the appointment menu
function displayEmployeeMenu() {
  console.log('\nEmployee Management System\n');
  console.log('1. Add Employee');
  console.log('2. View All Employees');
  console.log('3. Update Employees Information');
  console.log('4. Delete Employee');
  console.log('5. Back to Main Menu\n');

  handleEmployeeMenuChoice();
}

// Function to display the appointment menu
function displayRentMenu() {
  console.log('\nRent Management Menu\n');
  console.log('1. Add Rent');
  console.log('2. View All Rents');
  console.log('3. Update Rent');
  console.log('4. Delete Rent');
  console.log('5. Back to Main Menu\n');

  handleRentMenuChoice();
}

/*
FUNCTIONS TO HANDLE CHOICES 
*/

// Function to handle choices in the renter menu
function handleRenterMenuChoice() {
  rl.question('Enter your choice: ', (choice) => {
    switch (choice) {
      case '1':
        addRenter();
        break;
      case '2':
        viewRenters();
        break;
      case '3':
        updateRenter();
        break;
      case '4':
        deleteRenter();
        break;
      case '5':
        displayAllMenu();
        break;
      default:
        console.log('\nInvalid choice. Please try again.\n');
        displayRenterMenu();
    }
  });
}

// Function to handle choices in the appointment menu
function handleAppointmentMenuChoice() {
  rl.question('Enter your choice: ', (choice) => {
    switch (choice) {
      case '1':
        addAppointment();
        break;
      case '2':
        viewAllAppointments();
        break;
      case '3':
        updateAppointment();
        break;
      case '4':
        deleteAppointment();
        break;
      case '5':
        displayAllMenu();
        break;
      default:
        console.log('\nInvalid choice. Please try again.\n');
        displayAppointmentMenu();
    }
  });
}

// Function to handle choices in the appointment menu
function handleTruckMenuChoice() {
  rl.question('Enter your choice: ', (choice) => {
    switch (choice) {
      case '1':
        addTruck();
        break;
      case '2':
        viewAllTrucks();
        break;
      case '3':
        updateTruck();
        break;
      case '4':
        deleteTruck();
        break;
      case '5':
        displayAllMenu();
        break;
      default:
        console.log('\nInvalid choice. Please try again.\n');
        displayTruckMenu();
    }
  });
}

// Function to handle choices in the appointment menu
function handleEmployeeMenuChoice() {
  rl.question('Enter your choice: ', (choice) => {
    switch (choice) {
      case '1':
        addEmployee();
        break;
      case '2':
        viewAllEmployees();
        break;
      case '3':
        updateEmployee();
        break;
      case '4':
        deleteEmployee();
        break;
      case '5':
        displayAllMenu();
        break;
      default:
        console.log('\nInvalid choice. Please try again.\n');
        displayTruckMenu();
    }
  });
}

// Function to handle choices in the appointment menu
function handleRentMenuChoice() {
  rl.question('Enter your choice: ', (choice) => {
    switch (choice) {
      case '1':
        addRent();
        break;
      case '2':
        viewAllRents();
        break;
      case '3':
        updateRent();
        break;
      case '4':
        deleteRent();
        break;
      case '5':
        displayAllMenu();
        break;
      default:
        console.log('\nInvalid choice. Please try again.\n');
        displayTruckMenu();
    }
  });
}

/*
FUNCTIONS FOR CRUD OPERATIONS
*/

/* RENTER CRUD */

// Function to add a new renter and save to MySQL
function addRenter() {
  rl.question('Enter renter name: ', (name) => {
    rl.question('Enter renter age: ', (age) => {
      rl.question('Enter renter contact: ', (contact) => {
        rl.question('Enter renter address: ', (address) => {
          rl.question('Enter renter email: ', (email) => {
            const sql = 'INSERT INTO renter (renter_name, renter_age, renter_contact, renter_address, renter_email) VALUES (?, ?, ?, ?, ?)';
            const values = [name, age, contact, address, email];

            connection.query(sql, values, (error, results) => {
              if (error) throw error;

              console.log('\nRenter added successfully!\n');
              displayRenterMenu();
            });
          });
        });
      });
    });
  });
}

// Function to view all renters
function viewRenters() {
  const sql = 'SELECT * FROM renter';

  connection.query(sql, (error, results) => {
    if (error) throw error;

    if (results.length > 0) {
      console.log('\nList of Renters:\n');
      console.table(results);
    } else {
      console.log('\nNo Current Renters.\n');
    }

    displayRenterMenu();
  });
}

// Function to update all renter information
function updateRenter() {
  rl.question('Enter renter ID to update: ', (renterId) => {
    const sqlSelect = 'SELECT * FROM renter WHERE renter_id = ?';

    connection.query(sqlSelect, renterId, (error, results) => {
      if (error) throw error;

      if (results.length > 0) {
        const currentRenter = results[0];

        console.log('\nCurrent Renter Information:\n');
        console.table([currentRenter]);

        rl.question(`Enter new renter name (${currentRenter.renter_name}): `, (newName) => {
          rl.question(`Enter new renter age (${currentRenter.renter_age}): `, (newAge) => {
            rl.question(`Enter new renter contact (${currentRenter.renter_contact}): `, (newContact) => {
              rl.question(`Enter new renter address (${currentRenter.renter_address}): `, (newAddress) => {
                rl.question(`Enter new renter email (${currentRenter.renter_email}): `, (newEmail) => {
                  const sqlUpdate = `
                    UPDATE renter 
                    SET renter_name = ?, renter_age = ?, renter_contact = ?, renter_address = ?, renter_email = ?
                    WHERE renter_id = ?
                  `;

                  const values = [
                    newName || currentRenter.renter_name,
                    newAge || currentRenter.renter_age,
                    newContact || currentRenter.renter_contact,
                    newAddress || currentRenter.renter_address,
                    newEmail || currentRenter.renter_email,
                    renterId
                  ];

                  connection.query(sqlUpdate, values, (updateError, updateResults) => {
                    if (updateError) throw updateError;

                    console.log('\nRenter information updated successfully!\n');
                    displayRenterMenu();
                  });
                });
              });
            });
          });
        });
      } else {
        console.log(`\nNo data found for renter ID ${renterId}.\n`);
        displayRenterMenu();
      }
    });
  });
}

// Function to delete a renter
function deleteRenter() {
  rl.question('Enter renter ID to delete: ', (renterId) => {
    const sqlDelete = 'DELETE FROM renter WHERE renter_id = ?';

    connection.query(sqlDelete, renterId, (deleteError, deleteResults) => {
      if (deleteError) throw deleteError;

      if (deleteResults.affectedRows > 0) {
        console.log('\nRenter deleted successfully!\n');
      } else {
        console.log(`\nError: No data found for renter ID ${renterId}.\n`);
      }

      displayRenterMenu();
    });
  });
}

/* APPOINTMENT CRUD */

// Function to add a new appointment
function addAppointment() {
  // Check if there are any renters available
  const checkRenterSql = 'SELECT * FROM renter LIMIT 1';

  connection.query(checkRenterSql, (checkRenterError, checkRenterResults) => {
    if (checkRenterError) throw checkRenterError;

    if (checkRenterResults.length === 0) {
      console.log('\nError: There are no renters available. Please add a renter first.\n');
      displayAppointmentMenu();
      return;
    }

    // Fetch and display the available renters
    const fetchRentersSql = 'SELECT renter_id, renter_name FROM renter';
    connection.query(fetchRentersSql, (fetchRentersError, fetchRentersResults) => {
      if (fetchRentersError) throw fetchRentersError;

      console.log('\nAvailable Renters:');
      console.table(fetchRentersResults);

      rl.question('\nEnter renter ID: ', (renterId) => {
        const selectedRenter = fetchRentersResults.find((renter) => renter.renter_id === parseInt(renterId));

        if (!selectedRenter) {
          console.log('\nError: Invalid renter ID. Please select a valid renter.\n');
          displayAppointmentMenu();
          return;
        }

        rl.question('Enter appointment date (YYYY-MM-DD): ', (appointmentDate) => {
          rl.question('Enter start date (YYYY-MM-DD): ', (startDate) => {
            rl.question('Enter end date (YYYY-MM-DD): ', (endDate) => {
              const startDateTime = new Date(startDate);
              const endDateTime = new Date(endDate);

              if (startDateTime >= endDateTime) {
                console.log('\nError: End date must be later than the start date.\n');
                displayAppointmentMenu();
                return;
              }

              // Calculate total days
              const totalDays = Math.ceil((endDateTime - startDateTime) / (1000 * 60 * 60 * 24));

              // Proceed with adding an appointment
              // Insert the new purpose into the 'purpose' table
              rl.question('Enter a new purpose: ', (newPurpose) => {
                const insertPurposeSql = 'INSERT INTO purpose (description) VALUES (?)';
                connection.query(insertPurposeSql, [newPurpose], (insertPurposeError, insertPurposeResults) => {
                  if (insertPurposeError) throw insertPurposeError;

                  const purposeId = insertPurposeResults.insertId; // Get the ID of the newly added purpose

                  const sql = 'INSERT INTO appointment (renter_id, appointment_date, purpose_id, total_days, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?)';
                  const values = [renterId, appointmentDate, purposeId, totalDays, startDate, endDate];

                  connection.query(sql, values, (error, results) => {
                    if (error) throw error;

                    console.log('\nAppointment added successfully!\n');
                    displayAppointmentMenu();
                  });
                });
              });
            });
          });
        });
      });
    });
  });
}

// Function to view all appointments
function viewAllAppointments() {
  const sql = 'SELECT * FROM appointment';

  connection.query(sql, (error, results) => {
    if (error) throw error;

    if (results.length === 0) {
      console.log('\nNo current appointments found.\n');
    } else {
      console.log('\nList of Appointments:\n');
      console.table(results);
    }

    displayAppointmentMenu();
  });
}

// Function to update an appointment
function updateAppointment() {
  rl.question('Enter appointment ID to update: ', (appointmentId) => {
    const sqlSelect = `
      SELECT * FROM Appointment WHERE appointment_id = ? `;

    connection.query(sqlSelect, appointmentId, (selectError, selectResults) => {
      if (selectError) throw selectError;

      if (selectResults.length > 0) {
        const currentAppointment = selectResults[0];

        console.log('\nCurrent Appointment Information:\n');
        console.table([currentAppointment]);

        // Fetch and display the available renters
    const fetchRentersSql = 'SELECT renter_id, renter_name FROM renter';
    connection.query(fetchRentersSql, (fetchRentersError, fetchRentersResults) => {
      if (fetchRentersError) throw fetchRentersError;

      console.log('\nAvailable Renters:');
      console.table(fetchRentersResults);

        rl.question('Enter new renter ID: ', (newRenterId) => {
          // Check if the provided renter ID exists in the 'renters' table
          const checkRenterSql = 'SELECT * FROM renter WHERE renter_id = ?';
          connection.query(checkRenterSql, newRenterId, (checkRenterError, checkRenterResults) => {
            if (checkRenterError) throw checkRenterError;

            if (checkRenterResults.length === 0) {
              console.log('\nError: No data found for the provided renter ID.\n');
              displayAppointmentMenu();
              return;
            }

            rl.question('Enter new appointment date (YYYY-MM-DD): ', (newAppointmentDate) => {
              rl.question('Do you want to:\n1. Select a new purpose from the list\n2. Create a new purpose\nEnter your choice: ', (purposeChoice) => {
                if (purposeChoice === '1') {
                  // Fetch and display the available purposes for selection
                  const fetchPurposesSql = 'SELECT purpose_id, description FROM purpose';
                  connection.query(fetchPurposesSql, (fetchPurposesError, fetchPurposesResults) => {
                    if (fetchPurposesError) throw fetchPurposesError;

                    console.log('\nAvailable Purposes:\n');
                    console.table(fetchPurposesResults);

                    rl.question('Enter new purpose ID from the list above: ', (newPurposeId) => {
                      // Check if the provided purpose ID exists in the 'purposes' table
                      const checkPurposeSql = 'SELECT * FROM purpose WHERE purpose_id = ?';
                      connection.query(checkPurposeSql, newPurposeId, (checkPurposeError, checkPurposeResults) => {
                        if (checkPurposeError) throw checkPurposeError;

                        if (checkPurposeResults.length === 0) {
                          console.log('\nError: No data found for the provided purpose ID.\n');
                          displayAppointmentMenu();
                          return;
                        }

                        rl.question('Enter start date (YYYY-MM-DD): ', (newStartDate) => {
                          rl.question('Enter end date (YYYY-MM-DD): ', (newEndDate) => {
                            const startDateTime = new Date(newStartDate);
                            const endDateTime = new Date(newEndDate);
          
                            if (startDateTime >= endDateTime) {
                              console.log('\nError: End date must be later than the start date.\n');
                              displayAppointmentMenu();
                              return;
                            }
          
                            // Calculate total days
                            const newTotalDays = Math.ceil((endDateTime - startDateTime) / (1000 * 60 * 60 * 24));

                          // Perform the UPDATE operation
                          const sqlUpdate = `
                            UPDATE appointment
                            SET renter_id = ?, appointment_date = ?, purpose_id = ?, total_days = ?, start_date = ?, end_date = ?
                            WHERE appointment_id = ?
                          `;

                          const updateValues = [
                            newRenterId,
                            newAppointmentDate,
                            newPurposeId,
                            newTotalDays,
                            newStartDate,
                            newEndDate,
                            appointmentId
                          ];

                          connection.query(sqlUpdate, updateValues, (updateError, updateResults) => {
                            if (updateError) throw updateError;

                            console.log('\nAppointment updated successfully!\n');
                            displayAppointmentMenu();
                          });
                        });
                      });
                    });
                  });
                });
                } else if (purposeChoice === '2') {
                  rl.question('Enter a new purpose: ', (newPurpose) => {
                    // Insert the new purpose into the 'purposes' table
                    const insertPurposeSql = 'INSERT INTO purpose (description) VALUES (?)';
                    connection.query(insertPurposeSql, [newPurpose], (insertPurposeError, insertPurposeResults) => {
                      if (insertPurposeError) throw insertPurposeError;

                      const newPurposeId = insertPurposeResults.insertId; // Get the ID of the newly added purpose

                      rl.question('Enter start date (YYYY-MM-DD): ', (newStartDate) => {
                        rl.question('Enter end date (YYYY-MM-DD): ', (newEndDate) => {
                          const startDateTime = new Date(newStartDate);
                          const endDateTime = new Date(newEndDate);
        
                          if (startDateTime >= endDateTime) {
                            console.log('\nError: End date must be later than the start date.\n');
                            displayAppointmentMenu();
                            return;
                          }
        
                          // Calculate total days
                          const newTotalDays = Math.ceil((endDateTime - startDateTime) / (1000 * 60 * 60 * 24));

                        // Perform the UPDATE operation
                        const sqlUpdate = `
                          UPDATE appointment
                          SET renter_id = ?, appointment_date = ?, purpose_id = ?, total_days = ?, start_date = ?, end_date = ?
                          WHERE appointment_id = ?
                        `;

                        const updateValues = [
                          newRenterId,
                          newAppointmentDate,
                          newPurposeId,
                          newTotalDays,
                          newStartDate,
                          newEndDate,
                          appointmentId
                        ];

                        connection.query(sqlUpdate, updateValues, (updateError, updateResults) => {
                          if (updateError) throw updateError;

                          console.log('\nAppointment updated successfully!\n');
                          displayAppointmentMenu();
                        });
                      });
                    });
                  });
                });
                } else {
                  console.log('\nInvalid choice. Please try again.\n');
                  displayAppointmentMenu();
                }
              });
            });
          });
        });
      });
      } else {
        console.log(`\nError: No data found for appointment ID ${appointmentId}.\n`);
        displayAppointmentMenu();
      }
    });
  });
}

// Function to delete an appointment
function deleteAppointment() {
  rl.question('Enter appointment ID to delete: ', (appointmentId) => {
    const sqlDelete = 'DELETE FROM appointment WHERE appointment_id = ?';

    connection.query(sqlDelete, appointmentId, (deleteError, deleteResults) => {
      if (deleteError) throw deleteError;

      if (deleteResults.affectedRows > 0) {
        console.log('\nAppointment deleted successfully!\n');
      } else {
        console.log(`\nError: No data found for appointment ID ${appointmentId}.\n`);
      }

      displayAppointmentMenu();
    });
  });
}

/* Truck CRUD */

// Function to add a new truck
function addTruck() {
  rl.question('Enter truck name: ', (truckName) => {
    rl.question('Enter truck cubic capacity: ', (truckCapacity) => {
      rl.question('Enter truck price: ', (truckPrice) => {
        rl.question('Enter plate number: ', (plateNumber) => {
          const sqlSelectStatus = 'SELECT * FROM status';

          connection.query(sqlSelectStatus, (selectStatusError, selectStatusResults) => {
            if (selectStatusError) throw selectStatusError;

            if (selectStatusResults.length > 0) {
              console.log('\nAvailable Statuses:\n');
              console.table(selectStatusResults);

              rl.question('Enter status ID: ', (statusId) => {
                const sqlInsert = 'INSERT INTO truck (truck_name, truck_capacity, truck_price, plate_number, status_id) VALUES (?, ?, ?, ?, ?)';
                const values = [truckName, truckCapacity, truckPrice, plateNumber, statusId];

                connection.query(sqlInsert, values, (insertError, insertResults) => {
                  if (insertError) throw insertError;

                  console.log('\nTruck added successfully!\n');
                  displayTruckMenu();
                });
              });
            } else {
              console.log('\nNo statuses found.\n');
              displayTruckMenu();
            }
          });
        });
      });
    });
  });
}

// Function to view all trucks
function viewAllTrucks() {
  const sqlSelectAll = 'SELECT * FROM truck';

  connection.query(sqlSelectAll, (selectError, selectResults) => {
    if (selectError) throw selectError;

    if (selectResults.length > 0) {
      console.log('\nAll Trucks:\n');
      console.table(selectResults);
    } else {
      console.log('\nNo trucks found.\n');
    }

    displayTruckMenu();
  });
}


// Function to update a truck
function updateTruck() {
  rl.question('Enter truck ID to update: ', (truckId) => {
    const sqlSelect = 'SELECT * FROM truck WHERE truck_id = ?';

    connection.query(sqlSelect, truckId, (selectError, selectResults) => {
      if (selectError) throw selectError;

      if (selectResults.length > 0) {
        const currentTruck = selectResults[0];

        console.log('\nCurrent Truck Information:\n');
        console.table([currentTruck]);

        rl.question('Enter new truck name: ', (newTruckName) => {
          rl.question('Enter new truck cubic capacity: ', (newTruckCapacity) => {
            rl.question('Enter new truck price: ', (newTruckPrice) => {
              rl.question('Enter new plate number: ', (newPlateNumber) => {
                const sqlSelectStatus = 'SELECT * FROM status';

                connection.query(sqlSelectStatus, (selectStatusError, selectStatusResults) => {
                  if (selectStatusError) throw selectStatusError;

                  if (selectStatusResults.length > 0) {
                    console.log('\nAvailable Statuses:\n');
                    console.table(selectStatusResults);

                    rl.question('Enter new status ID: ', (newStatusId) => {
                      const sqlUpdate = 'UPDATE trucks SET truck_name = ?, truck_capacity = ?, truck_price = ?, plate_number = ?, status_id = ? WHERE truck_id = ?';
                      const updateValues = [newTruckName, newTruckCapacity, newTruckPrice, newPlateNumber, newStatusId, truckId];

                      connection.query(sqlUpdate, updateValues, (updateError, updateResults) => {
                        if (updateError) throw updateError;

                        console.log('\nTruck updated successfully!\n');
                        displayTruckMenu();
                      });
                    });
                  } else {
                    console.log('\nNo statuses found.\n');
                    displayTruckMenu();
                  }
                });
              });
            });
          });
        });
      } else {
        console.log(`\nError: No data found for truck ID ${truckId}.\n`);
        displayTruckMenu();
      }
    });
  });
}

// Function to delete a truck
function deleteTruck() {
  rl.question('Enter truck ID to delete: ', (truckId) => {
    const sqlDelete = 'DELETE FROM truck WHERE truck_id = ?';

    connection.query(sqlDelete, truckId, (deleteError, deleteResults) => {
      if (deleteError) throw deleteError;

      if (deleteResults.affectedRows > 0) {
        console.log('\nTruck deleted successfully!\n');
      } else {
        console.log(`\nError: No data found for truck ID ${truckId}.\n`);
      }

      displayTruckMenu();
    });
  });
}

/* Employee CRUD */

// Function to add a new employee
function addEmployee() {
  rl.question('Enter employee name: ', (employeeName) => {
    rl.question('Enter employee contact: ', (employeeContact) => {
      rl.question('Enter employee age: ', (employeeAge) => {
        rl.question('Enter employee type: ', (employeeType) => {
          rl.question('Enter license number: ', (licenseNumber) => {
            const sqlInsert = 'INSERT INTO employee (employee_name, employee_contact, employee_age, employee_type, license_no) VALUES (?, ?, ?, ?, ?)';
            const values = [employeeName, employeeContact, employeeAge, employeeType, licenseNumber];

            connection.query(sqlInsert, values, (insertError, insertResults) => {
              if (insertError) throw insertError;

              console.log('\nEmployee added successfully!\n');
              displayEmployeeMenu();
            });
          });
        });
      });
    });
  });
}

// Function to view all employees
function viewAllEmployees() {
  const sqlSelectAll = 'SELECT * FROM employee';

  connection.query(sqlSelectAll, (selectError, selectResults) => {
    if (selectError) throw selectError;

    if (selectResults.length > 0) {
      console.log('\nAll Employees:\n');
      console.table(selectResults);
    } else {
      console.log('\nNo employees found.\n');
    }

    displayEmployeeMenu();
  });
}

// Function to update an employee
function updateEmployee() {
  rl.question('Enter employee ID to update: ', (employeeId) => {
    const sqlSelect = 'SELECT * FROM employee WHERE employee_id = ?';

    connection.query(sqlSelect, employeeId, (selectError, selectResults) => {
      if (selectError) throw selectError;

      if (selectResults.length > 0) {
        const currentEmployee = selectResults[0];

        console.log('\nCurrent Employee Information:\n');
        console.table([currentEmployee]);

        rl.question('Enter new employee name: ', (newEmployeeName) => {
          rl.question('Enter new employee contact: ', (newEmployeeContact) => {
            rl.question('Enter new employee age: ', (newEmployeeAge) => {
              rl.question('Enter new employee type: ', (newEmployeeType) => {
                rl.question('Enter new license number: ', (newLicenseNumber) => {
                  const sqlUpdate = 'UPDATE employee SET employee_name = ?, employee_contact = ?, employee_age = ?, employee_type = ?, license_no = ? WHERE employee_id = ?';
                  const updateValues = [newEmployeeName, newEmployeeContact, newEmployeeAge, newEmployeeType, newLicenseNumber, employeeId];

                  connection.query(sqlUpdate, updateValues, (updateError, updateResults) => {
                    if (updateError) throw updateError;

                    console.log('\nEmployee updated successfully!\n');
                    displayEmployeeMenu();
                  });
                });
              });
            });
          });
        });
      } else {
        console.log(`\nError: No data found for employee ID ${employeeId}.\n`);
        displayEmployeeMenu();
      }
    });
  });
}

// Function to delete an employee
function deleteEmployee() {
  rl.question('Enter employee ID to delete: ', (employeeId) => {
    const sqlDelete = 'DELETE FROM employee WHERE employee_id = ?';

    connection.query(sqlDelete, employeeId, (deleteError, deleteResults) => {
      if (deleteError) throw deleteError;

      if (deleteResults.affectedRows > 0) {
        console.log('\nEmployee deleted successfully!\n');
      } else {
        console.log(`\nError: No data found for employee ID ${employeeId}.\n`);
      }

      displayEmployeeMenu();
    });
  });
}

/* Rent CRUD */

// Function to add a new rent
function addRent() {
  rl.question('Enter employee ID: ', (employeeId) => {
    rl.question('Enter truck ID: ', (truckId) => {
      rl.question('Enter rent cost: ', (rentCost) => {
        rl.question('Enter appointment ID: ', (appointmentId) => {
          const sqlInsert = 'INSERT INTO rent (employee_id, truck_id, rent_cost, appointment_id) VALUES (?, ?, ?, ?)';
          const values = [employeeId, truckId, rentCost, appointmentId];

          connection.query(sqlInsert, values, (insertError, insertResults) => {
            if (insertError) throw insertError;

            console.log('\nRent added successfully!\n');
            displayRentMenu();
          });
        });
      });
    });
  });
}

// Function to view all rents
function viewAllRents() {
  const sqlSelectAll = 'SELECT * FROM rent';

  connection.query(sqlSelectAll, (selectError, selectResults) => {
    if (selectError) throw selectError;

    if (selectResults.length > 0) {
      console.log('\nAll Rents:\n');
      console.table(selectResults);
    } else {
      console.log('\nNo rents found.\n');
    }

    displayRentMenu();
  });
}

// Function to update a rent
function updateRent() {
  rl.question('Enter rent ID to update: ', (rentId) => {
    const sqlSelect = 'SELECT * FROM rent WHERE rent_id = ?';

    connection.query(sqlSelect, rentId, (selectError, selectResults) => {
      if (selectError) throw selectError;

      if (selectResults.length > 0) {
        const currentRent = selectResults[0];

        console.log('\nCurrent Rent Information:\n');
        console.table([currentRent]);

        rl.question('Enter new employee ID: ', (newEmployeeId) => {
          rl.question('Enter new truck ID: ', (newTruckId) => {
            rl.question('Enter new rent cost: ', (newRentCost) => {
              rl.question('Enter new appointment ID: ', (newAppointmentId) => {
                const sqlUpdate = 'UPDATE rents SET employee_id = ?, truck_id = ?, rent_cost = ?, appointment_id = ? WHERE rent_id = ?';
                const updateValues = [newEmployeeId, newTruckId, newRentCost, newAppointmentId, rentId];

                connection.query(sqlUpdate, updateValues, (updateError, updateResults) => {
                  if (updateError) throw updateError;

                  console.log('\nRent updated successfully!\n');
                  displayRentMenu();
                });
              });
            });
          });
        });
      } else {
        console.log(`\nError: No data found for rent ID ${rentId}.\n`);
        displayRentMenu();
      }
    });
  });
}


// Function to delete a rent
function deleteRent() {
  rl.question('Enter rent ID to delete: ', (rentId) => {
    const sqlDelete = 'DELETE FROM rent WHERE rent_id = ?';

    connection.query(sqlDelete, rentId, (deleteError, deleteResults) => {
      if (deleteError) throw deleteError;

      if (deleteResults.affectedRows > 0) {
        console.log('\nRent deleted successfully!\n');
      } else {
        console.log(`\nError: No data found for rent ID ${rentId}.\n`);
      }

      displayRentMenu();
    });
  });
}